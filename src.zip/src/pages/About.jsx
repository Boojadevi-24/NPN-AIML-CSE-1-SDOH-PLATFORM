function About() {
  return (
    <div className="about-page">
      <section className="about-hero">
        <h2>About Us</h2>
        <p>
          The SDOH Health Platform connects healthcare data with social, 
          environmental, and community insights to reduce inequities and 
          improve health outcomes. Our mission is to give doctors, NGOs, and 
          policymakers powerful tools to make smarter decisions.
        </p>
      </section>

      <section className="about-sections">
        <div className="about-card">
          <h3>🌍 Geocoding & Spatial Analysis</h3>
          <p>
            We map health risks across regions using geocoding and spatial 
            analysis. This highlights areas with poor housing, limited food 
            access, or lack of transportation, helping target interventions 
            effectively.
          </p>
        </div>

        <div className="about-card">
          <h3>🔗 Multi-Source Data Integration</h3>
          <p>
            By integrating healthcare, social, environmental, and economic 
            datasets, our platform creates a 360° view of community well-being, 
            enabling holistic and data-driven decisions.
          </p>
        </div>

        <div className="about-card">
          <h3>⚖️ Health Equity Measurement</h3>
          <p>
            We measure disparities in access and outcomes to ensure fair 
            allocation of resources and to close health equity gaps for 
            vulnerable populations.
          </p>
        </div>

        <div className="about-card">
          <h3>🤖 Predictive Modeling</h3>
          <p>
            Our predictive models forecast how social factors affect future 
            health outcomes. This enables proactive planning and early 
            intervention to prevent risks.
          </p>
        </div>

        <div className="about-card">
          <h3>🗺️ Community Resource Mapping</h3>
          <p>
            We identify and map community resources — from food centers and 
            hospitals to transportation services — ensuring interventions are 
            timely and impactful.
          </p>
        </div>
        <div className="about-card">
  <h3>🆔 E-Health Card</h3>
  <p>
    Our platform provides a secure digital health card for individuals. 
    This E-Card helps people store their health records safely and share 
    them with doctors or healthcare providers when needed. It ensures 
    easy access to medical history and supports better care decisions.
  </p>
</div>

      </section>
    </div>
  );
}

export default About;
