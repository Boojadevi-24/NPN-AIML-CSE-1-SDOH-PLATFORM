function Services() {
  const services = [
    {
      title: "🆔 E-Health Card",
      desc: "A secure digital health card for storing and sharing medical records.",
      img: "https://cdn-icons-png.flaticon.com/512/2920/2920244.png"
    },
    {
      title: "🗺️ Community Risk Map",
      desc: "Interactive maps showing vulnerable areas based on SDOH data.",
      img: "https://cdn-icons-png.flaticon.com/512/854/854929.png"
    },
    {
      title: "📤 Data Upload",
      desc: "Upload patient and community datasets for analysis.",
      img: "https://cdn-icons-png.flaticon.com/512/1828/1828911.png"
    },
    {
      title: "📝 Patient Registration",
      desc: "Register new patients with demographics and health details.",
      img: "https://cdn-icons-png.flaticon.com/512/1256/1256650.png"
    },
    {
      title: "🏘️ SDOH Data Form",
      desc: "Collect data on housing, food, transport, income, and education.",
      img: "https://cdn-icons-png.flaticon.com/512/883/883407.png"
    },
    {
      title: "📊 Insights Dashboard",
      desc: "View trends, predictions, and equity analysis with charts.",
      img: "https://cdn-icons-png.flaticon.com/512/1828/1828884.png"
    }
  ];

  return (
    <div className="services-page">
      <h2>Our Services</h2>
      <div className="service-cards">
        {services.map((service, i) => (
          <div key={i} className="service-card">
            <img src={service.img} alt={service.title} />
            <h3>{service.title}</h3>
            <p>{service.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Services;

