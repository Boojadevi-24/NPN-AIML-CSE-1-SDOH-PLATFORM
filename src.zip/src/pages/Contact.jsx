function Contact() {
  return (
    <div className="contact">
      <h2>Contact Us</h2>
      <p>Email: support@sdohplatform.org</p>
      <p>Phone: +91 9876543210</p>
      <p>Address: SDOH Research Center, India</p>
    </div>
  );
}
export default Contact;




  