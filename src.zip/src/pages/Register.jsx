function Register() {
  return (
    <div className="register-page">   {/* ✅ same as CSS */}
      <div className="register-box">
        <h2>Register</h2>
        <form>
          <input type="text" placeholder="Full Name" required />
          <input type="email" placeholder="Email" required />
          <input type="password" placeholder="Password" required />
          <button type="submit">Sign Up</button>
        </form>

        <div className="social-login">
          <button className="google">Login with Google</button>
          <button className="facebook">Login with Facebook</button>
        </div>
      </div>
    </div>
  );
}

export default Register;
