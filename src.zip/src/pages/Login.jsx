function Login() {
  return (
    <div className="login-page">   {/* ✅ must match CSS */}
      <div className="login-box">
        <h2>Login</h2>
        <form>
          <input type="email" placeholder="Email" required />
          <input type="password" placeholder="Password" required />
          <a href="#">Forgot Password?</a>
          <button type="submit">Login</button>
        </form>
      </div>
    </div>
  );
}
export default Login;
;
