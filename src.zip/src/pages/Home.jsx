import { Link } from "react-router-dom";

function Home() {
  return (
    <div className="home">
      <header className="hero">
        {/* Left side text */}
        <div className="hero-text">
          <h1>Welcome to SDOH Health Platform</h1>
          <p>
  Our platform combines geocoding and spatial analysis with 
  multi-source data integration from health, social, and environmental 
  domains. Using health equity measurement frameworks and predictive 
  modeling, we identify how social determinants impact outcomes, while 
  community resource mapping helps target the right interventions at 
  the right time.
</p>

          <Link to="/about"><button className="btn">View More</button></Link>
        </div>

        {/* Right side image */}
        <div className="hero-image">
  <img 
    src="https://cdn-icons-png.flaticon.com/512/3774/3774299.png" 
    alt="Doctor Illustration" 
  />
</div>




      </header>
    </div>
  );
}

export default Home;

