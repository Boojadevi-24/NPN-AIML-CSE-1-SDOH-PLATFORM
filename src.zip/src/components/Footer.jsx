function Footer() {
  return (
    <footer className="footer">
      <p>© 2025 SDOH Health Platform | All Rights Reserved</p>
      <p>Made with ❤️ for Healthcare Equity</p>
    </footer>
  );
}
export default Footer;
